#!/bin/bash

cppython http_test_server.py