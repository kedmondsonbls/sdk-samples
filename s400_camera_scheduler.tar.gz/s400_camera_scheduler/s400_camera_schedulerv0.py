import time
import datetime
import logging
from csclient import EventingCSClient

client = EventingCSClient('gpio1_scheduler')
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("gpio1_scheduler")

PIN = 1

def initialize_gpio():
    logger.info(f"Configuring GPIO pin {PIN}")
    client.put(f"/config/system/gpio_actions/pin/{PIN}/direction", "out")
    client.put(f"/config/system/gpio_actions/pin/{PIN}/io_type", "lvttl")
    client.put(f"/config/system/gpio_actions/pin/{PIN}/level", "high")
    client.put(f"/config/system/gpio_actions/pin/{PIN}/enabled", False)
    time.sleep(0.2)

def is_weekday():
    return datetime.datetime.now().weekday() < 5  # Monday = 0, Sunday = 6

def is_active_time():
    now = datetime.datetime.now()
    return now.hour >= 6 and now.hour < 17

def set_gpio(state: bool):
    client.put(f"/config/system/gpio_actions/pin/{PIN}/enabled", state)
    logger.info(f"GPIO {PIN} set {'HIGH' if state else 'LOW'}")

def run_scheduler():
    logger.info("Starting GPIO 1 weekday scheduler...")
    last_state = None
    while True:
        active = is_weekday() and is_active_time()
        if active != last_state:
            set_gpio(active)
            last_state = active
        time.sleep(60)

if __name__ == "__main__":
    initialize_gpio()
    run_scheduler()
