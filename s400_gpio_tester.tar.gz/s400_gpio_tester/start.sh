#!/bin/bash

cppython s400_gpio_tester.py