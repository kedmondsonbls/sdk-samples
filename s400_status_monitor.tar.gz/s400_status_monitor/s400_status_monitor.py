import time
import datetime
import logging
import requests
from csclient import EventingCSClient

client = EventingCSClient("s400_status_monitor")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("s400_status_monitor")

GPIO_PIN = 1
PRTG_URL = "http://<PRTG_SERVER_IP>/public/api/pushsensor.exe?sensor=<sensor_id>&token=s400status"  # Replace with your real values

def get_camera_power_state():
    try:
        state = client.get(f"/config/system/gpio_actions/pin/{GPIO_PIN}/enabled")
        return 1 if state else 0
    except Exception as e:
        logger.warning(f"⚠️ GPIO read error: {e}")
        return 0

def get_system_temperature():
    try:
        temp_raw = client.get("/status/system/temperature")
        if temp_raw is None:
            raise ValueError("Temperature is None")
        return float(temp_raw)
    except Exception as e:
        logger.warning(f"⚠️ Temp read error: {e}")
        return None

def get_system_voltage():
    try:
        voltage_raw = client.get("/status/power_usage/voltage")
        if voltage_raw is None:
            raise ValueError("Voltage is None")
        return float(voltage_raw)
    except Exception as e:
        logger.warning(f"⚠️ Voltage read error: {e}")
        return None

def get_lte_metric(path, name):
    try:
        raw = client.get(path)
        return float(raw) if raw is not None else None
    except Exception as e:
        logger.warning(f"⚠️ {name} read error: {e}")
        return None

def push_to_prtg(data):
    prtg_payload = {
        "prtg": {
            "result": [
                {"channel": "Voltage", "value": data["voltage"] or 0},
                {"channel": "Temperature", "value": data["temperature"] or 0},
                {"channel": "CameraPower", "value": data["camera_power_on"]},
            ],
            "text": f"Last update: {data['timestamp']}"
        }
    }
    try:
        response = requests.post(PRTG_URL, json=prtg_payload, timeout=5)
        logger.info(f"✅ PRTG update sent: {response.status_code}")
    except Exception as e:
        logger.warning(f"❌ Failed to send PRTG update: {e}")

def main():
    while True:
        voltage = get_system_voltage()
        temp = get_system_temperature()
        camera_on = get_camera_power_state()
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        logger.info(f"📡 {timestamp} | V: {voltage} V | T: {temp}°C | Cam: {'ON' if camera_on else 'OFF'}")

        data = {
            "timestamp": timestamp,
            "voltage": voltage,
            "temperature": temp,
            "camera_power_on": camera_on
        }

        push_to_prtg(data)
        time.sleep(60)

if __name__ == "__main__":
    main()
