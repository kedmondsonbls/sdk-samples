#!/bin/bash

cppython s400_camera_scheduler.py