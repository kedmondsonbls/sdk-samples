#!/bin/bash

cppython s450_status_monitor.py