#!/bin/bash
cppython gpio2secondcycletest.py
