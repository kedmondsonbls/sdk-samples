#!/bin/bash
cppython s700gpiocontroller.py
